---
name: Suggestion
about: Have an idea or feature you'd like to see? Tell us here!
title: Hazard Nuker [ENHANCEMENT]
labels: enhancement
assignees: [DeKrypted,Rdimo]

---

*Please fill out the following:*

**What you'd like to see:**


**(OPTIONAL) How it would be implemented:**

